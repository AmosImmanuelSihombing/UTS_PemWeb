<?php
include '../koneksi.php';

// PROSES DATA SAAT FORM DISUBMIT
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama = $_POST["nama"];
  $email = $_POST["email"];
  $judul = $_POST["judul"];
  $pesan = $_POST["pesan"];

  // INSERT DATA KE DATABASE
  $sql = "INSERT INTO kontak (nama, email, judul, pesan)
              VALUES ('$nama', '$email', '$judul', '$pesan')";

  if ($koneksi->query($sql) === TRUE) {
    echo 'BERHASIL';
  } else {
    echo 'GAGAL';
  }
}

$koneksi->close();
